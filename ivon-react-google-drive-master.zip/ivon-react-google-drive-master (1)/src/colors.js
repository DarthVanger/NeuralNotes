export const colors = {
  lightGray: '#888',
  darkGray: '#333',
};
