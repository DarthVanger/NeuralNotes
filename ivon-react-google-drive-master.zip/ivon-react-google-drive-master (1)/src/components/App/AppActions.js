export const CHANGE_PAGE_ACTION = 'CHANGE_PAGE_ACTION';
export const ROOT_NOTE_FOUND_ACTION = 'ROOT_NOTE_FOUND_ACTION';

export const rootNoteFoundAction = (data) => ({ type: ROOT_NOTE_FOUND_ACTION, data });
