export const PAGES_ENUM = {
  LOADING: Symbol('loading'),
  LOGIN: Symbol('login'),
  NOTES: Symbol('notes')
};
