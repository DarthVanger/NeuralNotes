export default {
    white: '#fff',
    black: '#000',
    aqua: '#96ffff',
    rainfull: '#131C3E',
    denim: '#0E1736',
    pearl: '#E8E9F8',
    blue: '#4A51F5'
}
