import styled from 'styled-components';

export const StyledNotesMindMap = styled.div`
  position: absolute;
  bottom: 0;
  height: calc(100% - 50px);
  width: 100%;
`;
