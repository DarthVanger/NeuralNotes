export const CHANGE_USER_HELP_SEEN_ACTION  = 'CHANGE_USER_HELP_SEEN_ACTION';

export const changeUserHelpSeenAction = data => ({ type: CHANGE_USER_HELP_SEEN_ACTION, data });
