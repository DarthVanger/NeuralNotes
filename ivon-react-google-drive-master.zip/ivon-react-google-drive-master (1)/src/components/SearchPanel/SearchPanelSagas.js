import { all, call, takeEvery } from 'redux-saga/dist/redux-saga-effects-npm-proxy.cjs';
import { readHelpSeenState } from './readHelpSeenState';

// import { SEARCH_QUERY_CHANGED_ACTION, changeUserHelpSeenAction, } from 'components/SearchPanel/SearchPanelActions';

export const HELP_VIEWED_KEY = 'controls_help:viewed';

function* saveHelpSeenState({ data }) {
  yield call([localStorage, localStorage.setItem], HELP_VIEWED_KEY, data);
}

export function* notesInit() {
  yield all([
    readHelpSeenState(),
    takeEvery(CHANGE_USER_HELP_SEEN_ACTION, saveHelpSeenState),
  ]);
}
